# Apple Website

**Source** : https://www.apple.com/

## Colors
- Grey : #f5f5f7
- Blue : #06c
- White:  #fff
- Black: #000

## Assets
- Fonts: assets/fonts
- Logos : assets/logos
- Images : assets/images

## Fonts
- SF Pro Regular : All Text
- SF Pro Display Semibold : Subheadings
- SF Pro Semibold : Headings